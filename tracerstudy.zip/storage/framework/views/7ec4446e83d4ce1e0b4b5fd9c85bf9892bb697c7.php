<table>
  <thead>
    <tr>
      <th>kdptimsmh</th>
      <th>kdpstmsmh</th>
      <th>nimhsmsmh</th>
      <th>nmmhsmsmh</th>
      <th>telpomsmh</th>
      <th>emailmsmh</th>
      <th>tahun_lulus</th>
      <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th><?php echo e($item->kode); ?></th>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $F1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($item->kode_pt); ?></td>
        <td><?php echo e($item->kode_prodi); ?></td>
        <td><?php echo e($item->nim); ?></td>
        <td><?php echo e($item->nama_mahasiswa); ?></td>
        <td><?php echo e($item->no_hp); ?></td>
        <td><?php echo e($item->email); ?></td>
        <td><?php echo e(date('Y', strtotime($item->tgl_wisuda))); ?></td>
        <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($k->user_id == $item->user_id): ?>
            <td><?php echo e($k->isi); ?></td>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/view_export.blade.php ENDPATH**/ ?>
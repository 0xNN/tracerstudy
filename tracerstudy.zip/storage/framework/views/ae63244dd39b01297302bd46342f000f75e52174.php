<?php $__env->startSection('konten'); ?>

<h4>Pertanyaan Kuesioner</h4>
<div class="card">
    <form id="regForm" method="POST" action="<?php echo e(route('jawaban_user.store')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs" id="myTab">
                <?php $__currentLoopData = $datta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a href="#pertanyaan<?php echo e($items->id); ?>" class="nav-link" data-toggle="tab"><?php echo e($items->kode_pertanyaan); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
            <?php $__currentLoopData = $datta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade" id="pertanyaan<?php echo e($items->id); ?>">
                    <p class="mt-2">
                        Tipe Pertanyaan <span class="badge badge-success"><?php echo e($items->pertanyaan_tipe->tipe->nama_tipe); ?></span>
                    </p>
                    <h5 class="mt-2">
                        <input type="hidden" id="id_pertanyaan" value="<?php echo e($items->id); ?>" name="id_pertanya[<?php echo e($items->id); ?>]"><?php echo e($loop->iteration.'. '.$items->deskripsi_pertanyaan); ?>

                        <input type="hidden" id="nim_mahasiswa" name="nim_mahasiswa" value="<?php echo e(Session::get('nim')); ?>">
                    </h5>
                    
                    <div class="row">
                        <div class="col-sm-6">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        <?php if($items->pertanyaan_tipe->tipe->nama_tipe === 'Input'): ?> 
                            <input type="text" name="question_input_<?php echo e($items->id); ?>" class="form-control">
                        <?php endif; ?>
                        <?php if($items->pertanyaan_tipe->tipe->nama_tipe === 'Radio'): ?>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($items->id === $jawaban->pertanyaan_id): ?>
                                    <?php if(preg_match("/lainnya/i", $jawaban->deskripsi_jawaban)): ?>
                                        <div class="form-check">
                                            <input onclick="cek( <?php echo e($jawaban->id); ?>, 'radio' )" class="form-check-input" type="radio" name="question_radio_<?php echo e($items->id); ?>[]" id="question_radio_<?php echo e($jawaban->id); ?>" value="radio_<?php echo e($jawaban->id); ?>_from_<?php echo e($items->id); ?>">
                                            <label class="form-check-label" for="question_radio_<?php echo e($jawaban->id); ?>">
                                            <?php echo e($jawaban->deskripsi_jawaban); ?>

                                            </label>
                                        </div>
                                        <input style="display:none" class="form-control" type="text" name="question_radio_<?php echo e($items->id); ?>[]" id="question_radio_lainnya_<?php echo e($jawaban->id); ?>">
                                    <?php else: ?>
                                        <div class="form-check">
                                            <input onclick="cek( <?php echo e($jawaban->id); ?>, 'radio' )" class="form-check-input" type="radio" name="question_radio_<?php echo e($items->id); ?>[]" id="question_radio_<?php echo e($jawaban->id); ?>" value="radio_<?php echo e($jawaban->id); ?>_from_<?php echo e($items->id); ?>">
                                            <label class="form-check-label" for="question_radio_<?php echo e($jawaban->id); ?>">
                                            <?php echo e($jawaban->deskripsi_jawaban); ?>

                                            </label>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($items->pertanyaan_tipe->tipe->nama_tipe === 'Checkbox'): ?>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($items->id === $jawaban->pertanyaan_id): ?>
                                    <?php if(preg_match("/lainnya/i",$jawaban->deskripsi_jawaban)): ?>
                                        <div class="form-check">
                                            <input onclick="cek( <?php echo e($jawaban->id); ?>, 'checkbox' )" class="form-check-input" type="checkbox" name="question_checkbox_<?php echo e($items->id); ?>[]" id="question_checkbox_<?php echo e($jawaban->id); ?>" value="checkbox_<?php echo e($jawaban->id); ?>_from_<?php echo e($items->id); ?>">
                                            <label class="form-check-label" for="question_checkbox_<?php echo e($jawaban->id); ?>">
                                            <?php echo e($jawaban->deskripsi_jawaban); ?>

                                            </label>
                                        </div>
                                        <input style="display:none" class="form-control" type="text" name="question_checkbox_<?php echo e($items->id); ?>[]" id="question_checkbox_lainnya_<?php echo e($jawaban->id); ?>">
                                    <?php else: ?>
                                        <div class="form-check">
                                            <input onclick="cek( <?php echo e($jawaban->id); ?>, 'checkbox' )" class="form-check-input" type="checkbox" name="question_checkbox_<?php echo e($items->id); ?>[]" id="question_checkbox_<?php echo e($jawaban->id); ?>" value="checkbox_<?php echo e($jawaban->id); ?>_from_<?php echo e($items->id); ?>">
                                            <label class="form-check-label" for="question_checkbox_<?php echo e($jawaban->id); ?>">
                                            <?php echo e($jawaban->deskripsi_jawaban); ?>

                                            </label>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if($items->pertanyaan_tipe->tipe->nama_tipe === 'Radi'): ?>
                            <select name="question-<?php echo e($items->id); ?>" class="form-control">                            
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($items->id === $jawaban->pertanyaan_id): ?>
                                        <option value="<?php echo e($jawaban->id); ?>"><?php echo e($jawaban->deskripsi_jawaban); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div>
        <?php $__currentLoopData = $datta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="step"></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="card-footer">
            <button class="btn btn-sm btn-success" type="submit">Simpan</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        function cek(jawaban, tipe)
        {
            // console.log(jawaban);
            // console.log(tipe);
            var id = `question_${tipe}_${jawaban}`;
            // console.log(id);
            var nilai = document.getElementById(id).value;
            // console.log(nilai);

            var id_lainnya = `#question_${tipe}_lainnya_${jawaban}`;
            // var id_lainnya = `#question-${tipe}-lainnya`;
            if(document.getElementById(id).checked) {
                $.get(`Kuesioner/get-data/${jawaban}`, {
                    id: id
                },(response) => {
                    var kalimat = response['deskripsi_jawaban'];
                    var kata1 = kalimat.search('Lain');
                    var kata2 = kalimat.search('tulis');
                    if( kata1 > -1 || kata2 > -1 )
                    {
                        $(id_lainnya).val('');
                        // $(id_lainnya).show();
                        $(id_lainnya).show();
                    }
                    else {
                        $(id_lainnya).val('');
                        $(id_lainnya).hide();
                    }
                });
            }

            if(document.getElementById(id).checked == false) {
                $(id_lainnya).val('');
                // $(`#question-${tipe}-lainnya-${jawaban}`).hide();
                $(id_lainnya).hide();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/Kuesioner.blade.php ENDPATH**/ ?>
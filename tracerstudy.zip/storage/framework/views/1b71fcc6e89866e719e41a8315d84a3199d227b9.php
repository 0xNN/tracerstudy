
<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light bg-white mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
      <i class="fa fa-bars"></i>
    </button>
    <a class="navbar-brand" href="#">
      <img src="<?php echo e(asset('assets/img/logo.png')); ?>" width="40" height="40" alt="">
      STIHPADA - Sekolah Tinggi Ilmu Hukum Sumpah Pemuda
    </a>
    <!-- Topbar Search -->
    

    <!-- Topbar Navbar -->
    
    

      <!-- Nav Item - Alerts -->
      

    <!-- Nav Item - User Information -->
    <ul class="navbar-nav ml-auto">
      <div class="topbar-divider d-none d-sm-block"></div>
        <!-- Authentication Links -->
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            </li>
            <?php if(Route::has('register')): ?>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
              </li>
            <?php endif; ?>
        <?php else: ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><?php echo e(Auth::user()->name); ?></a>
                  <div class="dropdown-menu">
                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                          <?php echo e(__('Logout')); ?>

                      </a>
                  </div>
            </li>
        <?php endif; ?>
    </ul>
  </nav>
  <!-- End of Topbar -->
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/utama/header.blade.php ENDPATH**/ ?>
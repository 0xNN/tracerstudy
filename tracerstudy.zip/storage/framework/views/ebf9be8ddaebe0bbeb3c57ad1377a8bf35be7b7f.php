

<?php $__env->startSection('konten'); ?>
  <?php if($jawaban_status == null): ?>      
    <h1>Kuesioner</h1>
    <div class="accordian" id="accordionExample">
      <form action="<?php echo e(route('jawaban_user.store')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <?php $__currentLoopData = $all_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
          <div class="card-header" id="heading<?php echo e($item['id']); ?>">
            <h2 class="mb-0">
              <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($item['id']); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($item['id']); ?>">
                <?php echo e($item->kode_pertanyaan); ?> - <?php echo e($item->deskripsi_pertanyaan); ?>

              </button>
            </h2>
          </div>
    
          <div id="collapse<?php echo e($item['id']); ?>" class="collapse show" aria-labelledby="heading<?php echo e($item['id']); ?>" data-parent="#accordionExample">
            <div class="card-body">
              <?php if($item['is_sub_pertanyaan'] == true): ?>
    
                <?php $__currentLoopData = $item['sub_pertanyaan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_pertanyaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <h4 class="card-title"><?php echo e($sub_pertanyaan['deskripsi_sub_pertanyaan']); ?></h4>
    
                  <?php $__currentLoopData = $item['jawaban']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                    <?php if($jawaban['sub_pertanyaan_id'] == $sub_pertanyaan['id']): ?>
                      <?php if($item['tipe'] === 'Radio'): ?>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="pertanyaan_sub_<?php echo e($sub_pertanyaan['kode_sub_pertanyaan']); ?>_<?php echo e($item['id']); ?>_<?php echo e($jawaban['nilai']); ?>" id="pertanyaan_sub_<?php echo e($sub_pertanyaan['kode_sub_pertanyaan']); ?>_<?php echo e($item['id']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                          <label class="form-check-label" for="pertanyaan_sub_<?php echo e($sub_pertanyaan['kode_sub_pertanyaan']); ?>_<?php echo e($item['id']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                            <?php echo e($jawaban['deskripsi_jawaban']); ?>

                          </label>
                        </div>
                      <?php endif; ?>
                    <?php endif; ?>
                    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <hr class="sidebar-divider">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
              <?php else: ?>
                <?php $__currentLoopData = $item['jawaban']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($item['tipe'] == 'Radio'): ?>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="radiopertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>" id="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($jawaban['nilai']); ?>" value="<?php echo e($jawaban['nilai']); ?>">
                      <label class="form-check-label" for="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                        <?php echo e($jawaban['deskripsi_jawaban']); ?>

                      </label>
                      <?php if(preg_match('/Lainnya/i',$jawaban['deskripsi_jawaban'])): ?>
                        <input class="form-control form-control-sm" type="text" name="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($jawaban['nilai']); ?>_lainnya" id="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($jawaban['nilai']); ?>_lainnya">
                      <?php endif; ?>
                    </div>
                  <?php elseif($item['tipe'] == 'Checkbox'): ?>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="checkboxpertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>_<?php echo e($item['id']); ?>[<?php echo e($jawaban['jawaban_id']); ?>]" id="pertanyaan_id_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($item['id']); ?>" value="<?php echo e($jawaban['nilai']); ?>">
                      <label class="form-check-label" for="pertanyaan_id_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($item['id']); ?>">
                        <?php echo e($jawaban['deskripsi_jawaban']); ?>

                      </label>
                      <?php if(preg_match('/Lainnya/i',$jawaban['deskripsi_jawaban'])): ?>
                        <input class="form-control form-control-sm" type="text" name="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($item['id']); ?>_lainnya_<?php echo e($jawaban['kode_jawaban']); ?>" id="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['id']); ?>_lainnya">
                      <?php endif; ?>
                    </div>
                  <?php elseif($item['tipe'] == 'Radio_input'): ?>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>" id="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                      <label class="form-check-label" for="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                        <?php echo e($jawaban['deskripsi_jawaban']); ?> 
                        <?php if(preg_match('/(...)(kira-kira)/i', $jawaban['deskripsi_jawaban'])): ?>
                          <input type="number" class="form-control form-control-sm" name="inputpertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                        <?php endif; ?>
                      </label>
                    </div>
                  <?php elseif($item['tipe'] == 'Range'): ?>
                    <label for="range_pertanyaan_id_<?php echo e($item['id']); ?>" class="form-label">
                      <h6><?php echo e($jawaban['deskripsi_jawaban']); ?></h6> 
                      <div id="range_pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_label" class="badge badge-warning">Sedang</div>
                    </label>
                    <div class="col-sm-6">
                      <input 
                        
                        
                        oninput="nilai(this.value, <?php echo e($item['id']); ?>, <?php echo e($jawaban['jawaban_id']); ?>)" 
                        type="range" 
                        class="form-control-range" 
                        min="1" 
                        max="5" 
                        id="range_pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>" 
                        name="rangepertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['jawaban_id']); ?>_<?php echo e($jawaban['kode']); ?>">
                        
                    </div>
                    <hr class="sidebar-divider">
                  <?php elseif($item['tipe'] == 'Input'): ?>
                    <label class="form-label" for="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                      <?php echo e($jawaban['deskripsi_jawaban']); ?>

                    </label>
                    <input class="form-control form-control-sm" type="number" name="inputpertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['nilai']); ?>" id="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                  <?php else: ?>
                    <label class="form-label" for="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                      <?php echo e($jawaban['deskripsi_jawaban']); ?>

                    </label>
                    <input class="form-control form-control-sm" type="number" name="inputpertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($item['kode_pertanyaan']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['jawaban_id']); ?>" id="pertanyaan_id_<?php echo e($item['id']); ?>_<?php echo e($jawaban['pertanyaan_id']); ?>_<?php echo e($jawaban['nilai']); ?>">
                  <?php endif; ?>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
              <?php endif; ?>
            </div>
          </div>
          <div class="card-footer">
          </div>
        </div>
        <hr class="sidebar-divider">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class="btn btn-primary btn-sm" type="submit">
          Simpan
        </button>
      </form>
    </div>
  <?php else: ?>
    <div class="alert alert-success" role="alert">
      <h1 class="alert-heading">Terima Kasih</h1>
      <p>Hai <?php echo e($user->nama_mahasiswa); ?>. Anda telah menyelesaikan kuesioner.</p>
      <hr class="my-4">
      <a class="btn btn-success" href="#">Bukti Selesai</a>
    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
      function nilai(value, id, jawaban_id, kode) {
        var s = "";
        // console.log(value);
        if(value == "1")
        {
          s = "Sangat Rendah";
        }
        else if(value == "2")
        {
          s = "Rendah";
        }
        else if(value == "3")
        {
          s = "Sedang";
        }
        else if(value == "4")
        {
          s = "Tinggi";
        }
        else {
          s = "Sangat Tinggi";
        }

        var data = $(`#range_pertanyaan_id_${id}_${jawaban_id}_label`).text(s);
        // console.log(data);
      }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/kuisioner.blade.php ENDPATH**/ ?>
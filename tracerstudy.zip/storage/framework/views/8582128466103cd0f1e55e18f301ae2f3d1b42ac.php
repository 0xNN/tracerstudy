

<?php $__env->startSection('konten'); ?>
<div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
  <div class="card card0 border-0">
      <div class="row d-flex" style="margin-bottom: -45px;">
          <div class="col-lg-6">
              <div class="card1 pb-5">
                  <div class="row"> <img src="<?php echo e(asset('assets/img/sumpah_pemuda_header.png')); ?>" class="logo"> </div>
                  <div class="row px-3 justify-content-center mt-4 mb-5 border-line"> <img src="<?php echo e(asset('assets/img/20180723_092402.jpg')); ?>" class="image"> </div>
              </div>
          </div>
          <div class="col-lg-6 mt-5">
              <div class="card2 card border-0 px-4 py-4">
                  
                  <form action="<?php echo e(route('login')); ?>" method="post">       
                    <?php echo csrf_field(); ?>           
                    <div class="row px-3 mb-4">
                        <div class="line"></div> <small class="or text-center">Login</small>
                        <div class="line"></div>
                    </div>
                    <div class="row px-3"> <label class="mb-1">
                            <h6 class="mb-0 text-sm">ID Mahasiswa</h6>
                        </label> <input class="mb-4" type="text" name="name" placeholder="Masukan ID Mahasiswa"> </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="row px-3"> <label class="mb-1">
                            <h6 class="mb-0 text-sm">Password</h6>
                        </label> <input type="password" name="password" placeholder="Masukan Password"> </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="row px-3 mb-4">
                        <div class="custom-control custom-checkbox custom-control-inline"> <input id="chk1" type="checkbox" name="chk" class="custom-control-input"> <label for="chk1" class="custom-control-label text-sm">Remember me</label> </div> <a href="<?php echo e(route('password.request')); ?>" class="ml-auto mb-0 text-sm">Forgot Password?</a>
                    </div>
                    <div class="row mb-3 px-3"> <button type="submit" class="btn btn-blue text-center"><?php echo e(__('Login')); ?></button> </div>
                    <div class="row mb-4 px-3"> <small class="font-weight-bold">Don't have an account? <a href="<?php echo e(route('register')); ?>" class="text-danger ">Register</a></small> </div>
                  </form>
              </div>
          </div>
      </div>
      <div class="bg-blue py-4">
          <div class="row px-3"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy; <?php echo e(date('Y')); ?>. All rights reserved.</small>
              <div class="social-contact ml-4 ml-sm-auto"> <span class="fa fa-facebook mr-4 text-sm"></span> <span class="fa fa-google-plus mr-4 text-sm"></span> <span class="fa fa-linkedin mr-4 text-sm"></span> <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span> </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tema.page_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/auth/login.blade.php ENDPATH**/ ?>
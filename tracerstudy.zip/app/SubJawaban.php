<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubJawaban extends Model
{
    protected $guarded = [];
    protected $table = 'sub_jawaban';
}

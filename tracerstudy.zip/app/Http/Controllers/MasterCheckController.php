<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MasterCheckController extends Controller
{
    //
}

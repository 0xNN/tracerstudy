<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipePertanyaan extends Model
{
    protected $guarded = [];
    protected $table = 'table_tipe_data';
}

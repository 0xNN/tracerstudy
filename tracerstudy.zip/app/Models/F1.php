<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class F1 extends Model
{
    protected $guarded = [];
    protected $table = 'f1';
}

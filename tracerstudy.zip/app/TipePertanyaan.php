<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipePertanyaan extends Model
{
    protected $guarded = [];
    protected $table = 'table_tipe_data';
}
